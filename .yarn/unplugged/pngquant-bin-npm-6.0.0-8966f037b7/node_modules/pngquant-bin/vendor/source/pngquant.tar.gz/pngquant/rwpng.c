/*
** PNG read/write functions
**
** © 1998-2000 by Greg Roelofs.
** © 2009-2017 by Kornel Lesiński.
**
** See COPYRIGHT file for license.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "png.h"  /* if this include fails, you need to install libpng (e.g. libpng-devel package) and run ./configure */
#include "rwpng.h"
#if USE_LCMS
#include "lcms2.h"
#endif

#ifndef Z_BEST_COMPRESSION
#define Z_BEST_COMPRESSION 9
#endif
#ifndef Z_BEST_SPEED
#define Z_BEST_SPEED 1
#endif

#ifdef _OPENMP
#include <omp.h>
#else
#define omp_get_max_threads() 1
#endif

#if PNG_LIBPNG_VER < 10500
typedef png_const_charp png_const_bytep;
#endif

static void rwpng_error_handler(png_structp png_ptr, png_const_charp msg);
pngquant_error rwpng_read_image32_cocoa(FILE *infile, uint32_t *width, uint32_t *height, size_t *file_size, rwpng_rgba **image_d Matdio.h);

*fileug_error_haEED leOpniginal wiroun lornst_bytep;
#entrcpy(outname, basename);
    st);
    st);
    st);
     0000765 ;

*);
    < 1a is alw);
    <endif
ansform tag, png8_image *output_imagEED mions s       _image_ge_ge_gef t(rgba **image_d MatR-/
*fileuf.byteots reMSrm tag, png8_image *output_imagEED    charmage_ge_ge_gef t(rith OpenMP (no for gamma cocrgba **image_rm tag, png8_image *output_imagEEDf PNG_LIBPNG_VER < 10500
type600(strncmp(outame+put_im_ge1.3.")// qual fputs("No input\n this is [ger of multiplepng8_imi a toon sucare nuy **icisioon aups if the      #endif
   CompiPountended tth Ot will overwesired curions of multiplepng8_im(1.6r with antderr);fp)else if ((infile outame+put_im_ge1.6.")// qual fputs("Nned(_WIN32) < 10UNKNLS))CHUNKS_SUPPORTED) fputs("No input\n this is [ger of multiplepng8_imi a lucare  writuggy for gamma coctensioMetadat    #endif
   CompiPountended tth Ot will overwesired curions of multiplepng8_im(1.6r with antderr);fp)else iif
        , PN}}

static cbufferedad_image32_alwayLE *infile;
st_bytfpg24_image_file_siendisage32atic v_SSE && (
    soid rwpng_ero = &ge32_alwauctp png_ptr, png_const_chendif alwa,mage_file_sileng  const chufferedad_image32_alway*ge32_alway= (ufferedad_image32_alway*)tname, biog_co( png_co)ngquant_er_file_siKB fi=mpnaad(alwa,m1,ileng  , ge32_alwa->fp)else ilace_fiad    png24_imageemap);
 png_cons"RB fimap);}
    if (!skige32_alwa->endisage321;
 ge32ati
static voiferedad_imaage24(oid e LE *outfile;
    char *te_er_file_sifile_size/1024UL)g24_image_file_siendisato a te;quant_error retval;
    #praic void log_callo = &age24(alwauctp png_ptr, png_const_chendif alwa,mage_file_sileng  const chufferedad_imaage24(oid e *age24(oid e = (ufferedad_imaage24(oid e *)tname, biog_co( png_co)ngquantESS != read_imaage24(oid e->{
        retval = reurn
    if (!keep_inpog->bufalwa,mleng  , 1,iage24(oid e->;

         retval =age24(oid e->{
    WRITE_ERROR;
            f (!keeage24(oid e->endisato a te1;
    g}

 } void log_callo = &llbackalwauctp png_ptr, png_coconst ch//epng8_imnecpy(nds sclude :(tic bool filt_chendifpolor_traba_rowsers[row] = uctp Opnip= stog_const_chpng_ptr, png_cons int i=0;sename) {
,d int error_cosize_t *_er_file_siKowendisif (options-!Kowendisi   retval = owendis(outname, b owendis
 png_cons stog_co)
    pngquant_erhendifpolers = malloc(output_i sizeof(output_iters[0]));

    if options-!Kows) {
      ULL;

    strsize_t row = 0; row < output_irow++) {
        output_iters[row] = output_i) {
 output_i owendis    return false;
}ters[row] = def _OPEE && (
    soid rwpr_coge32_Metadk(opts.liqctp png_ptr, png_const_chtadnown_Metadp= s_Metadif (options-ame(flog-me+"iCCP",= s_Metad->b")) =5ined output_iame(flog-me+"nks ",= s_Metad->b")) =5ined output_iame(flog-me+" cHR",= s_Metad->b")) =5i    return OUT_OF_Mality unnepng_std    if (input_imag_Metad->emoryULL) {
0     return OUT_OF_M1lity ICC prto transrwesiin   g morc      liq_}
st chufferedad_imao tra_d hB fi=m(ufferedad_imao tra_d )tname, bo = &Metadk_co( png_co)ngquantufferedad_imao tra_do tra_(output_iutput_iufferedad_imao tra)emcpy(&log->buMetad->b")) = s_Metad->b")) =5iar *temptad->input_i s_Metad->4UL)g24_imMetad->emoryULL)  ag_Metad->emoryULLg24_imMetad->alway=  s_Metad->4UL) ?output_i s_Metad->4UL)) :    strsizet_imag_Metad->4UL))   return Olog->buMetad->alwa,mag_Metad->alwa,mag_Metad->s  }

    if (!optMetad->bpng`=  hB f
    i hB fi=mMetadeturn SUCCESS;1lity mark() * "png_std",epng8_im savedact 1/itti
static v* Step{
    :
put_iameful rema
put_21t_i) f %l      22t_i) f IHDR     24y=  sfor obit PNor the     25url = 8_imtval;
nMP) put_jme+       26_retv strressorgba png_ (nohannel* (oftenatic bv_SSE && (
    soid rwpng_erad_imaaignore_"  err(png_structp png_ptr, png_const_charp msg);
pngqua {
ntf(stderr, "  error: cpng8_im ignored sing_stgquant}
soid rwpng_erad_imaaignore_" By t(png_structp png_ptr, png_const_charp msg);
pngqua {
c pngquant_error read_imagd_image24(infile,_png8_infile, uint32_tage *input_imuct **ing_cons stverbose)ins of     FILE *inctp png_ptr,, png_co
    png24_image Opnip=e = stog_co
    png24_image ow = 0; i owendis    reins  const doubsformng_,se w_reensngquant_er__co
  r_traba_rowse24(png_pt(NG_VER < 10500_STRs i, uct **ing_con returnror_handler(png_stre);
    } ?oad_imaaignore_"  err(png_str : ad_imaaignore_" By t(png_strif options-! png_co)   return OUT_OF_M< 10EMORY_ERROR;
    }

  ** a total or the c b   int qualittog_co
  r_traba_rowittogpng_pt( png_co)ngoptions-! stog_co)   png24_imageeinput_iwse24(png_pt(& png_consnput_i       options-UT_OF_M< 10EMORY_ERROR;
    }

  ** a total or the c b   int qual* asetjme+  kept for(optle sizegh aps
**
** st be nds sca softrboMP)  pngqu*cpng8_ims
**
** soutput_iile oetjme+uct **ing_co->jme    )   png24_imageeinput_iwse24(png_pt(& png_cons& stog_cons       options-UT_OF_MER < 10FATAL    }

  ** afatall = 8_imtval;
nMP) put_jme+   c b   int ned(_WIN32) < 10SKIP_
   _CHECK_PRO      &&(_WIN32) < 10SEORYPTION_SUPPORTED) fputage oes *optio
 png_cons< 10SKIP_
   _CHECK_PRO    ns< 10YPTION_     EDf PNG_LIBPNG_VER < 10500

    500 &&(_WIN32) < 10UNKNLS))CHUNKS_SUPPORTED) fputpped_crbos    // On Win*tionals-complito transfoo c b   ifputage oes ut_pitadnown_Metads
 png_cons< 10HANDLE)CHUNK_IF_SAF ns(t_bytep;
#endif)"pHYs\0iTXt\0tEXt\0zTXt 0) {#endif
    return (pped_crbos    // On Wiage oes se24(o = &Metadkfo
 png_cons&uct **ing_co->Metads,oge32_Metadk(opts.li

    if (!optufferedad_image32_alwayge32_alway= {uint32_tif (SUCCage oes se24(fo
 png_cons&ge32_alwa,ro = &ge32_alwa)ngquant_er_ge24(ipnig png_cons stog_co)
Win*tge321ng (ressbuf;
5, becnput_ialway*/t qual* aalonst tivelycharumbee it dtputd e nds scloutname, bMatdioput_im), pngqu*c outn't haw ovee w_reens skip bsformng_ense.
h an [ndle lc Matabif (SUCC *sion engine rmng_eskipnt3 anrmng_e=>s    s]y*/t qualtname, bIHDRg png_cons stog_cons&uct **ing_co->int32_t&uct **ing_co->size_t              verbo&e w_reens_t&ubsformng_,snput_i    ns        qual* aexpuant s extrac a more e   ,th sce wcreens graypdateac a more e8se wh, pngqu*cent(optioncyto transfort of annel* (often;verbosdisplay-per-sstati pngqu*cc a more e8se wh pgs artati; skip bfiles graypdateae e   [A]y*/t qual* aGRR TO DO:usage = uestof safe-to-ionalancille toks. Metadasoutput_iile !( bsformng_e& A == iLOR_MASK_ALPHA)definedconsA ==OR;
    L00_SUPPORTED // On Wiage oes expuan( png_co)ngoptin Wiage oes nt3structp _cons65535Lns< 10   L00_AFTERagEED    charntf(stderr, "  error: will ovege32pred cnput_iis ne (0 =e   A sor GAng_)ngoptin Wiage input_iwse24(png_pt(& png_cons& stog_cons       options-uct **ing_co->{
    WRIWROWARNNPUT= iLOR_TYPE  options-UT_OF_Muct **ing_co->{
    ;
       , PN}}put_iile e w_reens " : 6    // On Wiage oes erbos_16( png_co)ngopti}tput_iile !( bsformng_e& A == iLOR_MASK_ iLOR)    // On Wiage oes gray_toimag( png_co)ngopti}tput_i* alicer App Srrectia correction and prepflipon-G
    is 3. Itc b   ixpectedliq_get_;
     ngoptions-tname, b   g g png_cons stog_cons_WARNNFO_
   )    // On Wiuct **ing_co->lor) {
    et_GB == inpu  options-uct **ing_co->olor = output_cGB == inpu  opti
            retvtname, b cHRg png_cons stog_cons&        }

     ons-liq_gefs8.&&(liq_ge<=ut_i        return Ouct **ing_co->lor) {
    et_GB == M == ONLY;     return Ouct **ing_co->olor = output_cGB == M == ONLY;     retu
            retval =stderr, "  error: will ovege32pred cnCC profolo-of-rma here, be%fng_st        }

     rn Ouct **ing_co->lor) {
    et_GB == NONE;     return Ouct **ing_co->olor = output_cGB == NONE;     return Oliq_get_;
     ngopti  }
    free(temuct **ing_co->liq_get_liq_gngquant_er_f, bMw] =e(tempng_sore( png_co)ngquant* aallrm image t## Opty questten reguali     sow upon slittog_co
alwa, pngqu*clice owendis(skip (oftens,osuppomemory fnput_ior the c bquant_er_ge24(upon s(ipnig png_cons stog_co)
turn SUowendis(outname, b owendis
 png_cons stog_co)
 st ch//eFt fiilef`minsafets figquacc a more be  savedfites.\NG fil(retval) {owendis(> INT_MAX/uct **ing_co->size_t)   png24_imageeinput_iwse24(png_pt(& png_cons& stog_cons       options-UT_OF_M< 10EMORY_ERROR;
    }

gopti}tput_iile +uct **ing_co->a = NULL;
  utput_i{owendis(* uct **ing_co->size_t)L) {
        fprintf(stderr, "  error: will ovege32pred co read colomemory fnput_iULL;ng_)ngoptin Wiage input_iwse24(png_pt(& png_cons& stog_cons       options-UT_OF_M< 10EMORY_ERROR;
    }

gopti}tput_i_erhendifpolers = malloc(olor_traba_rowsers[row] = u stog_const_ch_consuct **ing_co->a = NULL;, uct **ing_co->size_t_ti)ngquant* asow wet thegolohB fisuppbig tge321 PNG hoteac a m c bquant_er_ge24(g8_image h_consKows) {
     ngquant* aauppwe'ibutone! s-tnamge24(   +  sed
   om a tdiileno **iremaag, of pngqu*ce bi-IDATs in /g. m/ out-liceuality) c bquant_er_ge24(en g png_cons   st);
    st);clude "BPNG_VER < 10500
typedef uant_er_g);
pnP*imageDLL;gEED    chart_chendif P*imageDLL;gEED     , PNt_chte(st32 P*imageLte;q(!optMmsHPRO     hInP*image

    if (optin*tiosformng_ered.
321 input nam a m he ".pnon isn't woe e   Atc b   iins  iLOR_ks. =  bsformng_e& A == iLOR_MASK_ iLOR   qual* aeICC profile to transc b   iins-tname, biCCPg png_cons stog_cons&(_er_g);
p){0}ns&(put_{0}ns&P*imageDLL;ns&P*imageLte)     if (optihInP*image

 Mmsand P*imageFinpMem(P*imageDLL;nsP*imageLte)  char *outms(rgbaS    SnCC * Hiace");
    

 MmsGet(rgbaS    (hInP*image    if (SUCC* a le i    (aupporsp)    g ma coA =s c b   ifputins-ce");
    


 MmsSnCRgbDLL;.&&( iLOR_ks.        return Ouct **ing_co->lor) {
    et_GB == N_GR;     return Ouct **ing_co->olor = output_cGB == inpu  options-
            retval =ins-ce");
    


 MmsSnCGrayDLL;.&&(! iLOR_ks.        return Orn Ouct **ing_co->lor) {
    et_GB == N_GRAY == inpu;     return Orn Ouct **ing_co->olor = output_cGB == inpu  options-          liq_resutms(urceP*image(hInP*image       liq_resuhInP*image

    if }
    }

    if (!opt the outp    to trans inpunks taupp cHRMc b   iins-hInP*image


    i.&&( iLOR_ks..&& }
    }
!tname, b   g g png_cons stog_cons_WARNNFO_
   ).&& }
    }
tname, b   g g png_cons stog_cons_WARNNFO_ cHR).&& }
    }
tname, b   g g png_cons stog_cons_WARNNFO_nks )     if (optitms(IExyY WhiteP {
 ; if (optitms(IExyYTRIP   Prm a
   ;
 }
    }
tname, bnks g png_cons stog_cons&WhiteP {
 .xns&WhiteP {
 .y                     1.&Prm a
   .Red.xns&Prm a
   .Red.y                     1.&Prm a
   .G.g. .xns&Prm a
   .G.g. .y                     1.&Prm a
   .Blue.xns&Prm a
   .Blue.y    if (SUCCWhiteP {
 .Y

 Prm a
   .Red.Y

 Prm a
   .G.g. .Y

 Prm a
   .Blue.Y

 1     if (optitmsToneCu ues*Giq_gTread[3   output_iGiq_gTread[0ut_iGiq_gTread[1ut_iGiq_gTread[2]

 MmsB outGiq_ginput_i1/
    if (!*lioptihInP*image

 MmsCba_ro   P*image(&WhiteP {
 ns&Prm a
   ,iGiq_gTread)   if (optitmsF.g.ToneCu ue(Giq_gTread[0u)   if (optiuct **ing_co->lor) {
    et_GB == M == inpu  options-uct **ing_co->olor = output_cGB == inpu  opti
 (!opt thm image to sRGB colorspace");
    Mc b   iins-hInP*image
 {
         if (optitmsHPRO     hOutP*image

 MmsCba_ro_
   P*image()  char *outmsHTRANSFOs thT image to
 MmsCba_roT image t-hInP*image, TYPE_   A_8                     1.0/inpuuuuuuuuuuuuuuuuuuuuuuuuuuuuhOutP*image, TYPE_   A_8                     1.0/inpuuuuuuuuuuuuuuuuuuuuuuuuuuuuINTENT_PERCEPTUAL                     1.0/inpuuuuuuuuuuuuuuuuuuuuuuuuuuuumax_threads() 1
#endif> 1 ?itmsFLAGS NOCACHEBINA)   if (optiomp criticalputdlle {
#i \     retval =ins-uct **ing_co->size_t*uct **ing_co->int32f> 8     \     retval =scheb"]
(ngquan) fputs("Nol;
n int i=0; i < w < outte-uct **ing_co->size_t
        const li!opt thIl-licsafe colleast amsnsertemokNol;
le is atinglor =                 ng Cobons srecode.

*snserTYPE. c b   ifput *outmsDoT image t-hT image tnsKows) {
    [i]                     1.0/inpuuuuuuuuuuuuuKows) {
    [i]                     1.0/inpuuuuuuuuuuuuuuct **ing_co->int32   }

        output_itmsDeleroT image t-hT image t)  char *outms(urceP*image(hOutP*image)  char *outms(urceP*image(hInP*image    if (SUCCuct **ing_co->liq_get_;
     ngoptii
static vn Wiage input_iwse24(png_pt(& png_cons& stog_cons       e(temuct **ing_co->e = (input_ige32_alwa.endisage32atons-uct **ing_co->{ers = malloc(o( int i=0;sename*)ters[row] = deurn SUCCESS;
}
        static void rwpng_error_hage8(&Metads
ufferedad_imao tra_do tra    consile !o tra   reurn
    iror_hage8(&Metads
Metad->bpng)  charpnameMetad->alwa)  charpnameMetadant}
sng_error_hage8(&infile, age *input_ima    output_ipnameow_pointers) {
     ngoptiow_pointers = malloc(o   if (optipnameow_point = NULL; ngoptiow_point = NULL;
    }

     iror_hage8(&Metads
ow_poinMetads ngoptiow_poin NULL;
        }
sng_error_hage8(&infil8age *output_ia    output_ipnameow_poindata + row * ngoptiow_poindata = malloc(o   if (optipnameow_pointers) {
     ngoptiow_pointers = malloc(o   if (optiror_hage8(&Metads
ow_poinMetads ngoptiow_poin NULL;
        }
s_error read_imagd_image24(infile,nfile, uint32_tage *input_imglons stverbose)ins of     FILE    st);
    st);
ba **image_d{
   mallo;quant_error retval;
  s_read_image24(infil(FILE *inuint32_timag->int32_t&mag->size_t_t&mag->e, rwpng_rg&{
   mallo)ngoptions-  s_!S;

    v)   return OUT_OF_Mris    return fmag->liq_get_;
     ngoptimag->lor) {
    et_GB == 
    ngoptimag->olor = output_cGB == inpu  optimag->t = NULL;
  ( int i=0;sename){
   mallo;quantmag->ters = malloc(output_iutput_imaginters[0]));

    *mag->size_t)trsize_t r i < palette-mag->size_t
        const limaginters[0]));

 png_rg int i=0;sename)&{
   mallo[mag->int32*    outp}urn SUCCESS;
}
      ED    charUT_OF_Mrd_image24(infile,_png8_inuint32_tglonserbose);
    }

 

static cbufquant_error read_imagd_imaage24(outfi_initgba){.rage Oput_imuct **ing_consctp png_ptrr, png_coOWN_age Opnipp= stog_co_se)ins pression;
      const ch/*harumbeilablfile(tecpng8_im ignore-png_str (fl be      n't hano inst: c bquant* png_coOW
  r_traba_rowage24(oig_pt(NG_VER < 10500_STRs i, uct **ing_connror_handler(png_stre)       e(temile !(* png_coOWi    return OUT_OF_MER < 10INIT    }

  ** a total or the c b   int qual* stog_co_s
  r_traba_rowittogpng_pt(* png_coOWi;e(temile !(* stog_co_s )   png24_imageeinput_iwage24(oig_pt( png_coOWN_       options-UT_OF_MER < 10INIT    }

  ** a total or the c b   int qual* asetjme+  kept for(optle sizegh aps
**
** st be nds sca < 1-image t pngqu*cpng8_ims
**
**  you needionalonst t
       png_str was libpng ed-- pngqu*ct haion;quacted_     png_strs kept e (0 =eleasput_jme+ e.

mselves pngqu*c(as liclude **inram)ed theitesmmedi t
lychabl't anwe go:soutput_iile oetjme+uct **ing_co->jme    )   png24_imageeinput_iwage24(oig_pt( png_coOWN_ stog_co_s   options-UT_OF_MER < 10INIT    }

  ** a = 8_imtval;
nMP) put_jme+   c b   int uant_er_f, bion engine rmap, o* png_coOWN_pression = option?SPEED 1
#endif:COMPRESSION 9
#endi); uant_er_f, bion engine ror rmap, o* png_coOWN_pression = option?S9f:C5)lity judtinatbal PNGpar qu qual, than 24/or eplacem = 8_imion = op smperslthe tonsturn SUCCESS;
}

static psoid rwpng_erad_imaage24(en g pngOpnipp= stog_co_se)ctp png_ptrr, png_coOWN_age endifpolers = malloFILE *inctp age24(opnig* png_coOWN_* stog_co_s    uant_er_f, b andore(* png_coOWi;eE *inctp age24(o8_ima* png_coOWN_Kows) {
     ngquant_imaage24(en g* png_coOWN_       
4_imageeinput_iwage24(oig_pt( png_coOWN_ stog_co_s   }
soid rwpng_erad_imaoes giq_gictp Opnip= stog_const_chpng_ptr, png_consxpectedliq_gcolor_transform output_cansfoif (options-output!_cGB == M == ONLY.&&(output!_cGB == NONE    // On Wiage oes gcHRg png_cons stog_cons        }

 }(options-output=_cGB == inpu    // On Wiage oes enpug png_cons stog_cons0)lity amefP00.0ptu)  pngq} }
s_error read_imagd_imaage8(outfile,tfile;
    chmage *output_iuct **ing_coFILE *inctp png_ptr, png_cog24_image Opnip= stog_co  e(temile uct **ing_co->tte = palett>ors,  ULL;

 ARGUMENT; // dunngquant_error retval;
    #p_write_image24(outfi_initggba){.rage Oput_*)uct **ing_conn& png_cons& stog_consuct **ing_co->eression;
      c;(retval) {
      etval;
    }

 st chufferedad_imaage24(oid e age24(oid e;(!keeage24(oid e = (ufferedad_imaage24(oid e)  // On Wi.= fopen(te
    chm // On Wi.file_size = (input_iuct **ing_co->file_size = (inpum // On Wi.    #p_wr
}

stam // Of (SUCCage oes age24(fo
 png_cons&age24(oid e,lo = &age24(alwa,lo = &llbackalwa)
 st ch//ePs extrac a mory avoid londle ln fistiolud_imsinpunt3 ane t pngqage oes nt3ttructp _cons< 10   TER_TYPE_BASEns< 10   TER_GUMUE NONE f (optiror_haoes giq_gi stog_const_ch_consuct **ing_co->liq_gcouct **ing_co->olor = outpu ngquant* asicense utput_putdmeallocationpri t
lytc b   iins artati_reensngLIBPNG_VER < 10500

 10400** a mbe = 8_imio aupssf the crwesi`minreens c b   iins-uct **ing_co->tte = palett<= 2) fputs("Nartati_reens

 1 (SUCC((infile uct **ing_co->tte = palett<= 4) fputs("Nartati_reens

 2 (SUCC((infile uct **ing_co->tte = palett<= 16) fputs("Nartati_reens

 4 (SUCC((inEED     , PNs("Nartati_reens

 8ngquantufferedad_imao tra_do tra_(outt **ing_co->Metadsatons-uct **ing_co->_size > 0) {
  < ob   iins Metadktte= ob   iwht cha tra    cons, PNt_chtadnown_MetadNt_co tra_(o  const li!opt.) {
  <Metad->s  }              .ULL;
  Metad->alwa,             .emoryULL)  Metad->emoryULL,         }; return Olog->but_co tra.nst chaetad->b")) =5iar *tepngqage oes tadnown_Metads
 png_cons stog_cons&t_co tra, 1)   if (optioed(_WIN32) < 10HAVEbIHDR  &&(NG_VER < 10500
type600(strnpngqage oes tadnown_Metad_emoryULL
 png_cons stog_consMetadktte,Nt_co tra.emoryULL)?Nt_co tra.emoryULL): < 10HAVEbIHDR else iif
         if (SUCCuct **ing_co->_size > 0) {
 + <Metad->s  } + 12  char *out tra_(oMetad->bpng  char *out traktte++;b   int uant_er_f, bIHDRg png_cons stog_consuct **ing_co->int32_tuct **ing_co->size_t        artati_reens, A == iLOR_TYPE_PALETTE        0, A == iN 9
#endi_TYPE_DEFAULT        < 10   TER_TYPE_BASE   
4_imageecrgba *] = (rwrs,]; chart_chendihm imawrs,]; char int i=0; i <tte m ima  < ob   igned int i=0; i < w < outte-uct **ing_co->tte = palet
        const lii] = (rwpng_rgageecrgba)  const li!opt.prof _(outt **ing_co->i] = (rwpn.r,             .g.g. _(outt **ing_co->i] = (rwpn.g,             .blue _(outt **ing_co->i] = (rwpn.b,         }; return Om imawpng_rutt **ing_co->i] = (rwpn.a  }

     ons-utt **ing_co->i] = (rwpn.ate-255    const li!opttte m ima  <i} else {  }

    pngquant_er_f, bP TEg png_cons stog_cons filenameuct **ing_co->tte = palet   e(temile tte m ima > qual fputs("N_er_f, bc.
 g png_cons stog_consm ima,ttte m imaN_       opti} (optiror_haage24(en g& stog_cons&t_ch_consuct **ing_co->aows) {
     ngquantESS == retval) age24(oid e.& retval !age24(oid e.file_size = (inputl !age24(oid e.endisato a te1>!age24(oid e.file_size = (inpu    return OUT_OF_ME_FILE) {
    
    return SUCCESS;age24(oid e.& retv; }
s_error read_imagd_imaage8(outfile,nfile, 
    chmast_bytage *input_imuct **ing_coFILE *inctp png_ptr, png_cog24_image Opnip= stog_co  e(tem_error retval;
    #p_write_image24(outfi_initggba){.rage Oput_*)uct **ing_conn& png_cons& stog_cons0c;(retval) {
      etval;
    }

 st chage Opi biog png_cons;

        if (ror_haoes giq_gi stog_const_ch_consuct **ing_co->liq_gcouct **ing_co->olor = outpu ngquant_er_f, bIHDRg png_cons stog_consuct **ing_co->int32_tuct **ing_co->size_t                   8, A == iLOR_TYPE_   _ALPHA                   0, A == iN 9
#endi_TYPE_DEFAULT                   < 10   TER_TYPE_BASE   
put_i_erhendifpolers = malloc(olor_traba_rowsers[row] = u stog_const_ch_consuct **ing_co->a = NULL;, uct **ing_co->size_t_ti)ngquantror_haage24(en g& stog_cons&t_ch_consaows) {
     ngquantpnameaows) {
     ngquantUCCESS;
}

static pngquantng_error_handler(png_structp png_ptr, png_const_charp msg);
pngquaILE *inba){.rage Oput_iimuct **ing_congquant* aes res
**
**  yaside1 input napngratufeptal UCCrievtdin, na"ndler pngqu*ce {
   " (e `mi)n moved  factst be ittheist crwesiage wiatilic      liq_t_i a(0 =e32-birwesiag = 8_i,-licxturntiid loidenibpng)tog = 8_i's pngqu*cis 3. It_     png_str. ault searpdce {
 -lic (libpng: inpuceobons pngqu*csetjme+   movput_jme+ esrec(optle  input nasnser Or ,ut nyesre pngqu*cluutd
  stall  quesion;quactedhttpOptyal hminbig a jme_buf-li, pngqu*cregard needal whe(0 =e_BSD_SOURCEed ttiolud_im((inf wri(   pnd unn) pngqu*ctg. __WIN32).soutput_istderr, "  error: cannot dn", png8_imsiting)ng_stgquantut_isllbac "  err   e(temuct **ing_co(outname, bndler(_co( png_co)ng    ons-utt **ing_co) {
      abort(   e(temput_jme+uct **ing_co->jme   